#include <stdio.h>
#include <stdlib.h>
 
int main()
{
   float pantigo, pnovo;
   printf("Insira o preço antigo");
   scanf("%f",&pantigo);
   pnovo = pantigo*.9;
   printf("O preço novo, com desconto, é = %.2f",pnovo);
   return 0;
}
