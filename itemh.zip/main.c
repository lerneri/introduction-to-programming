#include <stdio.h>
#include <stdlib.h>
 
int main()
{
   int x, x2, x3, x4, x5, x6, x7, x8, x9, x10;
   printf("Insira um número inteiro:");
   scanf("%d",&x);
   x2 = x*2;
   x3 = x*3;
   x4 = x*4;
   x5 = x*5;
   x6 = x*6;
   x7 = x*7;
   x8 = x*8;
   x9 = x*9;
   x10 = x*10;
   printf("Essa é a tabuada do %d : \n%d x 1 = %d  \n%d x 2 = %d \n%d x 3 = %d  \n%d x 4 = %d \n%d x 5 = %d  \n%d x 6 = %d \n%d x 7 = %d \n%d x 8 = %d \n%d x 9 = %d \n%d x 10 = %d",x, x, x, x, x2, x, x3, x, x4, x, x5, x, x6, x, x7, x, x8, x, x9, x, x10);
   return 0;
}

