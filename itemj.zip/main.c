#include <stdio.h>
#include <stdlib.h>
int main()
{
   float c, f;
   printf("Insira o valor da temperatura em Celsius");
   scanf("%f",&c);
   f = 1.8*c+32;
   printf("Essa é a temperatura em Fahrenheint: %.f °F",f);
   return 0;
}
