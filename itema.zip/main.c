#include <stdio.h>
#include <stdlib.h>
 
int main()
{
   float n1, n2, avg;
   printf("Digite duas notas");
   scanf("%f %f",&n1,&n2);
   avg = (n1*2+n2*3)/(5);
   printf("A sua média é = %f",avg);
   return 0;
}


