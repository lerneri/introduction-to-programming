#include <stdio.h>
#include <stdlib.h>
 
int main()
{
   float b, B, h, s;
   printf("Base menor=");
   scanf("%f",&b);
   printf("Base maior=");
   scanf("%f",&B);
   printf("Altura=");
   scanf("%f",&h);
   s=(B+b)*h/2;
   printf("\nA área do trapézio é = %f",s);
   return 0;
}
