
#include <stdio.h>
#include <stdlib.h>
 
int main()
{
   float kg, g;
   printf("Insira o seu peso em quilogramas ");
   scanf("%f",&kg);
   g = kg*1000;
   printf("\nO seu peso em gramas é = %.3f",g);
   return 0;
}

