#include <stdio.h>
#include <stdlib.h>
 
int main()
{
   int yage, mage, dage, wage, ybirth, ycurrent;
   printf("Insira o ano atual:");
   scanf("%d",&ycurrent);
   printf("Insira o seu ano de nascimento:");
   scanf("%d",&ybirth);
   yage = ycurrent-ybirth;
   mage = yage*12;
   dage = yage*365;
   wage = yage*52;
   printf("\nSua idade é %d anos ou %d meses ou % d semanas ou %d dias", yage, mage, wage, dage);
   return 0;
}
