#include <stdio.h>
#include <stdlib.h>
 
int main()
{
   float power, h, b, s;
   printf("Insira o comprimento do cômodo em metros");
   scanf("%f",&h);
   printf("Insira a largura do cômodo em metros");
   scanf("%f",&b);
   s = b*h;
   printf("A área do cômodo é de %f metros quadrados", s);
   power = 18*s;
   printf("\nA potência necessária para iluminar o cômodo é %f W",power);

   return 0;
}
