#include <stdio.h>
#include <stdlib.h>
 
int main()
{
   float l, s;
   printf("Lado do quadrado=");
   scanf("%f",&l);
   s=l*l;
   printf("\nA área do quadrado é = %f",s);
   return 0;
}
