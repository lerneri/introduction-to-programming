#include <stdio.h>
#include <stdlib.h>
 
int main()
{
   float salariofixo, comissao, vendas, salariofinal;
   printf("Insira o salário fixo:");
   scanf("%f",&salariofixo);
   printf("\nInsira o valor recebido em vendas:");
   scanf("%f",&vendas);
   comissao = vendas*.04;
   printf("\nA comissão recebida é = %.2f",comissao);
   salariofinal = salariofixo+comissao;
   printf("\nO seu salário final é = %.2f",salariofinal);
   return 0;
}
