#include <stdio.h>
#include <stdlib.h>
 
int main()
{
   float min, qt, wage;
   printf("Insira o seu salário atual");
   scanf("%f",&wage);
   printf("Insira o valor do salário mínimo atual");
   scanf("%f",&min);
   qt = wage/min;
   printf("\nSeu salário equivale a %f salários mínimos",qt);
   return 0;
}
