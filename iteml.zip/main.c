#include <stdio.h>
#include <stdlib.h>
 
int main()
{
   float h, hextra, min, wage;
   printf("Insira o valor do salário mínimo atual: R$");
   scanf("%f",&min);
   printf("Insira o número de horas trabalhadas: ");
   scanf("%f",&h);
   printf("Insira o número de horas extras trabalhadas: ");
   scanf("%f",&hextra);
   wage = (h/8 + hextra/4)*min;
   printf("O salário a receber é R$%.2f", wage);
   return 0;
}
