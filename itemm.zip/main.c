#include <stdio.h>
#include <stdlib.h>
 
int main()
{
   float r, m, d, p;
   printf("Insira quantos reais você possui");
   scanf("%f",&r);
   d = r/3.95;
   m = r/4.25;
   p = r/5.8;
   printf("Seus %.2f reais equivalem a %.2f dólares, %.2f marcos alemães ou %.2f libras esterlinas ",r, d, m, p);
   return 0;
}
